#include <bits/stdc++.h>
using namespace std;

int main() {
  int a;
  scanf("%d", &a);
  if (a % 2 == 1) printf("Alice\n");
  else printf("Bob\n");
  return 0;
}