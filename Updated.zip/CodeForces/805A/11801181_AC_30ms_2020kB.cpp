#include <bits/stdc++.h>

using namespace std;

int main()
{ 
  int first,second;
  
  scanf("%d %d",&first,&second);
  
  if(first==second)
    printf("%d\n",first);
    
  else
  printf("2\n");
  
  
    return 0;
}