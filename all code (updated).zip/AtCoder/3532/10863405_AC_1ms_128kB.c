#include <stdio.h>
int main()
{
    int n, a;
    scanf("%d %d", &n, &a);
    printf("%d\n", (n*n)-a);
}
