#include <bits/stdc++.h>
using namespace std;

int main() {
    int i = 0;
    while (scanf("%d\n", &i) > 0 && i != 42) {
        printf("%d\n", i);
    }
    return 0;
}
